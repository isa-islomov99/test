<template>
  <div
    :style="{
      gridColumn: `${items.gridColumn}`,
      gridRow: `${items.gridRow}`,
      padding: '0 5px',
    }"
    :class="{ display: items.cssStyle }"
  >
    <label class="form-label">{{ items.label }}</label>
    <select
      v-if="items.type === 'select'"
      class="form-select mb-3 custom_input"
      aria-label="Default select example"
    >
      <option value=""></option>
      <option
        v-for="option in items.data"
        :key="option.id"
        :value="option.name"
      >
        {{ option.name }}
      </option>
    </select>
    <div v-else class="input-group input-group-sm mb-3">
      <input
        :type="items.type"
        :placeholder="items.placeholder"
        :class="[
          'form-control',
          'custom_input',
          { 'text-center': items.textAlign },
        ]"
        aria-label="Sizing example input"
        aria-describedby="inputGroup-sizing-sm"
      />
    </div>
  </div>
</template>

<script>
export default {
  props: {
    items: {
      type: Object,
      required: true,
    },
  },

  data() {
    return {
      input: null,
    };
  },

//   mounted() {
//     console.log(this.items);
//   },
};
</script>

<style  scoped>
.display {
  display: none;
}
.custom_input {
  height: 33px;
}
</style>